#define false 0
#define true 1

void swap(int *a, int *b);
void bubbleSort(int arr[], int n);
void insertionSort(int arr[], int n);
void selectionSort(int arr[], int n);
int thirdMax(int arr[], int n);