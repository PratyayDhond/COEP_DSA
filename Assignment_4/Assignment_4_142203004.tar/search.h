int isSorted(int arr[], int n);
void linearSearch(int arr[], int n, int element);
int binarySearch(int arr[], int low, int high, int element); 