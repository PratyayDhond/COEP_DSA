To compile the file with the custom header file use:
    ```
        gcc -o exe_name codeFile.c headerFile.c
    ```