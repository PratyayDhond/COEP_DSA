//GUARD
#ifndef MATHFUNCTIONS_H
#define MATHFUNCTIONS_H

float factorial(int n);

float toThePower(float n, int m);

#endif 